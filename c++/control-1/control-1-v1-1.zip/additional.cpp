#include "includes.h"
#include "additional.h"
#include "patient.h"

void print_message(string str) {
	cout << str;
}

vector<string> split_string(string str, char separator) {
	vector <string> strings;
	int startIndex = 0, endIndex = 0;
	for (int i = 0; i <= str.size(); i++) {
		if (str[i] == separator || i == str.size()) {
			endIndex = i;
			string temp;
			temp.append(str, startIndex, endIndex - startIndex);
			strings.push_back(temp);
			startIndex = endIndex + 1;
		}
	}
	return strings;
}

string writible_content_for_csv(vector<patient_data_full> data) {
	string to_return = patient::form_csv_header();
	if (data.empty()) return to_return;
	for (int i = 0; i < data.size(); i++) {
		to_return += patient::form_csv_string(data[i]);
	}
	return to_return;
}

string writible_content_for_console(vector<patient_data_full> data) {
	if (data.empty()) return "\n\n������ ��������!\n\n";
	string to_return;
	for (int i = 0; i < data.size(); i++) {
		to_return += patient::form_message(data[i]);
	}
	return to_return;
}

