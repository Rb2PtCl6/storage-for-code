#pragma once
#include "includes.h"
class file_worker {
private:
	enum file_type cl_type;
	ifstream in_file;
	ofstream out_file;
public:
	file_worker(enum file_type type, string file_name);
	string get_content();
	bool set_content(string content);
};
vector<patient_data> read_csv(string str);
vector<patient_data> file_reader();
void work_wiht_filename(string filename, string content);
void file_writer(string content);