#pragma once

#include <iostream>
#include <format>
#include <string>
#include <regex>
#include <fstream>
#include <filesystem>
#include <vector>
#include <map>

using namespace std;

struct patient_data {
	string name;
	string surname1;
	string surname2;
	string address;
	string diagnosis;
};

struct patient_data_full {
	int id;
	string name;
	string surname1;
	string surname2;
	string address;
	string diagnosis;
};

struct ret_srting {
	string str;
	bool ok;
};

struct ret_int {
	int num;
	bool ok;
};

struct ret_double {
	double num;
	bool ok;
};

enum file_type {
	in = 0,
	out = 1
};