#pragma once
#include "includes.h"

void print_message(string str);
vector<string> split_string(string str, char separator);
string writible_content_for_csv(vector<patient_data_full> data);
string writible_content_for_console(vector<patient_data_full> data);