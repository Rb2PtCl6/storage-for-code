#pragma once
#include "includes.h"
class patient {
private:
	string name;
	string surname1;
	string surname2;
	string address;
	int id;
	string diagnosis;

	static int max_id;

public:
	patient(patient_data data);
	patient_data_full get();
	patient_data_full get_by_id(int min, int max);
	patient_data_full get_by_diadnosis(string sort_diagnosis);
	string static form_message(patient_data_full data);
	string static form_csv_header();
	bool static is_valid_csv_header(string str);
	string static form_csv_string(patient_data_full data);
	bool static is_valid_field(string str, string mask);
	bool static is_filled_patient_data_full(patient_data_full data);
	bool static is_filled_patient_data(patient_data data);
};
patient_data enter_patient();
patient_data read_patient(string str);
void no_sort_launch(vector<patient> patients);
void id_sort_launch(vector<patient> patients);
void diagnosis_sort_launch(vector<patient> patients);