#pragma once
#include "includes.h"
class getter {
public:
	ret_srting static getString();
	ret_int static getInt();
	ret_double static getDouble();
};
string enter_filename();
int enter_sort_border();
string enter_sort_diagnosis();