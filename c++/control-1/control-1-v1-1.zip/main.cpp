#include "launcher.h"
#include "additional.h"

int main() {
	system("chcp 1251>nul");
	launcher();
	return EXIT_SUCCESS;
}